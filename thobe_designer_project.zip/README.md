Thobe Designer — Next.js (Web) + Express backend (Stripe test mode)
===============================================================

Quick start (development):

1. Start PostgreSQL (you can use Docker):
   docker run --name thobe-db -e POSTGRES_PASSWORD=postgres -e POSTGRES_USER=postgres -e POSTGRES_DB=thobe_db -p 5432:5432 -d postgres:15

2. Backend:
   cd backend
   npm install
   cp .env.example .env
   # set DATABASE_URL in .env if needed (default points to localhost)
   npx prisma generate
   npx prisma migrate dev --name init
   npm run seed
   npm run dev
   Backend default: http://localhost:4000

3. Web (Next.js):
   cd web
   npm install
   cp .env.local.example .env.local
   # set NEXT_PUBLIC_API_BASE to http://localhost:4000/api
   npm run dev
   Web default: http://localhost:3000

Notes:
- Stripe is configured in test mode. Replace STRIPE_SECRET and STRIPE_WEBHOOK_SECRET in backend/.env for real testing.
- The product images are placeholder URLs. For 360 viewer, multiple image URLs are used.
- Admin panel: /admin (simple password in .env for demo).

Enjoy!

