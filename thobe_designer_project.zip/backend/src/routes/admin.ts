import { Router } from 'express';
import dotenv from 'dotenv';
dotenv.config();
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
const r = Router();

// Simple admin auth (demo): use ADMIN_PASSWORD from .env
r.post('/login', async (req, res) => {
  const { password } = req.body;
  if (password === process.env.ADMIN_PASSWORD) return res.json({ ok: true });
  res.status(401).json({ error: 'unauthorized' });
});

r.post('/product', async (req, res) => {
  const { secret } = req.headers;
  if (secret !== process.env.ADMIN_PASSWORD) return res.status(401).json({ error: 'unauthorized' });
  const { name, slug, description, priceCents, images, variants } = req.body;
  try {
    const p = await prisma.product.create({ data: { name, slug, description, priceCents, images, variants } });
    res.json(p);
  } catch (e:any) {
    res.status(400).json({ error: e.message });
  }
});

export default r;
