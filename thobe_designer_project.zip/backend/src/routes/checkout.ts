import { Router } from 'express';
import Stripe from 'stripe';
import dotenv from 'dotenv';
import { PrismaClient } from '@prisma/client';
dotenv.config();
const stripe = new Stripe(process.env.STRIPE_SECRET || 'sk_test_fake', { apiVersion: '2024-08-01' });
const prisma = new PrismaClient();
const r = Router();

r.post('/create-session', async (req, res) => {
  const { items, email } = req.body;
  if (!items || !email) return res.status(400).json({ error: 'Missing' });

  const line_items = items.map((it: any) => ({
    price_data: {
      currency: 'usd',
      product_data: { name: it.name },
      unit_amount: it.priceCents,
    },
    quantity: it.qty
  }));

  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items,
      mode: 'payment',
      success_url: 'http://localhost:3000/checkout/success?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: 'http://localhost:3000/cart',
      customer_email: email
    });
    // Save order placeholder
    await prisma.order.create({
      data: { email, items, totalCents: items.reduce((s:any,i:any)=>s+i.qty*i.priceCents,0), stripeId: session.id }
    });
    res.json({ url: session.url });
  } catch (e:any) {
    console.error(e);
    res.status(500).json({ error: e.message });
  }
});

export default r;
