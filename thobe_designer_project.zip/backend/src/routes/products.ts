import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
const r = Router();

r.get('/', async (req, res) => {
  const products = await prisma.product.findMany({ orderBy: { createdAt: 'desc' }});
  res.json(products);
});

r.get('/:slug', async (req, res) => {
  const p = await prisma.product.findUnique({ where: { slug: req.params.slug } });
  if (!p) return res.status(404).json({ error: 'Not found' });
  res.json(p);
});

export default r;
