import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  await prisma.product.deleteMany();
  await prisma.order.deleteMany();

  await prisma.product.createMany({
    data: [
      {
        name: 'Riyadh Designer Thobe - Sand',
        slug: 'riyadh-designer-thobe-sand',
        description: 'Premium lightweight thobe in sand tone, tailored fit. Includes optional monogram.',
        priceCents: 9500,
        images: ['https://placehold.co/800x800?text=thobe1-1','https://placehold.co/800x800?text=thobe1-2','https://placehold.co/800x800?text=thobe1-3'],
        variants: JSON.stringify({ sizes: ['S','M','L','XL'], lengths: ['Regular','Long'], fabrics: ['Cotton','Linen'] })
      },
      {
        name: 'Jeddah Luxe Thobe - White',
        slug: 'jeddah-luxe-thobe-white',
        description: 'Crisp white thobe with refined collar, perfect for weddings and Eid.',
        priceCents: 12000,
        images: ['https://placehold.co/800x800?text=thobe2-1','https://placehold.co/800x800?text=thobe2-2','https://placehold.co/800x800?text=thobe2-3'],
        variants: JSON.stringify({ sizes: ['S','M','L','XL','XXL'], lengths: ['Regular','Long'], fabrics: ['Egyptian Cotton','Silk Blend'] })
      }
    ]
  });
  console.log('Seed done');
}

main().catch(e=>{console.error(e); process.exit(1);});
