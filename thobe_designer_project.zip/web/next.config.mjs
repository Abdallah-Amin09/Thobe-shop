export default {
  reactStrictMode: true,
  images: {
    domains: ['placehold.co'],
  },
};
