import { useState } from 'react';
import axios from 'axios';

export default function Admin() {
  const [pwd, setPwd] = useState('');
  const [ok, setOk] = useState(false);
  const [form, setForm] = useState({ name:'', slug:'', priceCents:10000, images: '', sizes:'S,M,L' });

  async function login() {
    try {
      await axios.post(`${process.env.NEXT_PUBLIC_API_BASE}/admin/login`, { password: pwd });
      setOk(true);
    } catch(e){ alert('Bad password'); }
  }

  async function create() {
    try {
      const images = form.images.split(',').map(s=>s.trim());
      const variants = { sizes: form.sizes.split(',').map(s=>s.trim()), lengths:['Regular','Long'], fabrics:['Cotton','Linen'] };
      await axios.post(`${process.env.NEXT_PUBLIC_API_BASE}/admin/product`, { ...form, images, variants }, { headers: { secret: pwd } });
      alert('Created');
    } catch(e:any){ alert('Error: '+ (e?.response?.data?.error || e.message)); }
  }

  if (!ok) return (
    <div style={{ padding: 20 }}>
      <h1>Admin login</h1>
      <input type="password" value={pwd} onChange={e=>setPwd(e.target.value)} />
      <button onClick={login}>Login</button>
    </div>
  );

  return (
    <div style={{ padding: 20 }}>
      <h1>Create product</h1>
      <input placeholder="name" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} /><br/>
      <input placeholder="slug" value={form.slug} onChange={e=>setForm({...form,slug:e.target.value})} /><br/>
      <input placeholder="priceCents" value={String(form.priceCents)} onChange={e=>setForm({...form,priceCents:Number(e.target.value)})} /><br/>
      <input placeholder="images (comma)" value={form.images} onChange={e=>setForm({...form,images:e.target.value})} /><br/>
      <input placeholder="sizes (comma)" value={form.sizes} onChange={e=>setForm({...form,sizes:e.target.value})} /><br/>
      <button onClick={create}>Create</button>
    </div>
  );
}
