import { useEffect, useState } from 'react';
import axios from 'axios';
import fetcher from '../src/utils/fetcher';

export default function Cart() {
  const [cart, setCart] = useState<any[]>([]);
  const [email, setEmail] = useState('test@example.com');
  useEffect(()=>{
    setCart(JSON.parse(localStorage.getItem('cart')||'[]'));
  },[]);

  const total = cart.reduce((s:any,i:any)=>s + i.qty * i.priceCents,0);

  async function checkout() {
    try {
      const res = await axios.post(`${process.env.NEXT_PUBLIC_API_BASE}/checkout/create-session`, { items: cart, email });
      window.location.href = res.data.url;
    } catch (e:any) {
      alert('Checkout failed: ' + (e?.response?.data?.error || e.message));
    }
  }

  return (
    <div className="cart">
      <h1>Your Cart</h1>
      {cart.map((it, idx)=>(
        <div key={idx} className="cart-item">
          <img src={it.image || ''} alt="" />
          <div>
            <h3>{it.name}</h3>
            <p>{it.size} {it.length} {it.fabric}</p>
            <p>Monogram: {it.monogram || '—'}</p>
            <p>Qty: {it.qty}</p>
            <p>Price: ${(it.priceCents/100).toFixed(2)}</p>
          </div>
        </div>
      ))}
      <h2>Total: ${(total/100).toFixed(2)}</h2>
      <label>Email for receipt</label>
      <input value={email} onChange={e=>setEmail(e.target.value)} />
      <button onClick={checkout} className="primary">Checkout (Stripe test)</button>
    </div>
  );
}
