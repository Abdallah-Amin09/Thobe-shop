import { useRouter } from 'next/router';
import { useEffect } from 'react';

export default function Success() {
  const router = useRouter();
  useEffect(()=>{
    localStorage.removeItem('cart');
  },[]);
  return (
    <div style={{ padding: 40 }}>
      <h1>Payment success</h1>
      <p>Thank you! Your order has been placed. You will receive an email receipt shortly (Stripe test).</p>
      <button onClick={()=>router.push('/')}>Back to shop</button>
    </div>
  );
}
