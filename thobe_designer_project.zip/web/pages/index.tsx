import Link from 'next/link';
import useSWR from 'swr';
import fetcher from '../src/utils/fetcher';

export default function Home() {
  const { data } = useSWR('/products', fetcher);
  const products = data || [];
  return (
    <div className="container">
      <header className="hero">
        <h1>Thobe Designer</h1>
        <p>Elegant, modern thobes — designer aesthetics inspired by classic craftsmanship.</p>
      </header>
      <section className="grid">
        {products.map((p:any)=>(
          <Link key={p.id} href={`/product/${p.slug}`} className="card">
            <img src={p.images[0]} alt={p.name} />
            <h3>{p.name}</h3>
            <p className="price">${(p.priceCents/100).toFixed(2)}</p>
          </Link>
        ))}
      </section>
    </div>
  );
}
