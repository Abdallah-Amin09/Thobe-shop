import { useRouter } from 'next/router';
import useSWR from 'swr';
import fetcher from '../../src/utils/fetcher';
import { useState } from 'react';
import ImageZoom from '../../src/components/ImageZoom';
import Viewer360 from '../../src/components/Viewer360';
import axios from 'axios';

export default function ProductPage() {
  const router = useRouter();
  const { slug } = router.query;
  const { data } = useSWR(slug ? `/products/${slug}` : null, fetcher);
  const product = data;
  const [size, setSize] = useState(null);
  const [length, setLength] = useState(null);
  const [fabric, setFabric] = useState(null);
  const [monogram, setMonogram] = useState('');
  const [qty, setQty] = useState(1);

  if (!product) return <div>Loading...</div>;
  const variants = JSON.parse(product.variants);

  async function addToCart() {
    const cart = JSON.parse(localStorage.getItem('cart')||'[]');
    cart.push({ productId: product.id, name: product.name, priceCents: product.priceCents, qty, size, length, fabric, monogram });
    localStorage.setItem('cart', JSON.stringify(cart));
    alert('Added to cart');
  }

  return (
    <div className="product">
      <div className="left">
        <Viewer360 images={product.images} />
        <ImageZoom src={product.images[0]} />
      </div>
      <div className="right">
        <h1>{product.name}</h1>
        <p className="price">${(product.priceCents/100).toFixed(2)}</p>
        <p>{product.description}</p>

        <div className="selectors">
          <label>Size</label>
          <select onChange={e=>setSize(e.target.value)}>
            <option value=''>Select size</option>
            {variants.sizes.map((s:string)=>(<option key={s} value={s}>{s}</option>))}
          </select>

          <label>Length</label>
          <select onChange={e=>setLength(e.target.value)}>
            <option value=''>Select length</option>
            {variants.lengths.map((l:string)=>(<option key={l} value={l}>{l}</option>))}
          </select>

          <label>Fabric</label>
          <select onChange={e=>setFabric(e.target.value)}>
            <option value=''>Select fabric</option>
            {variants.fabrics.map((f:string)=>(<option key={f} value={f}>{f}</option>))}
          </select>

          <label>Monogram (optional)</label>
          <input value={monogram} onChange={e=>setMonogram(e.target.value)} placeholder="Add initials" />

          <label>Quantity</label>
          <input type="number" value={qty} onChange={e=>setQty(Number(e.target.value))} min={1} />
        </div>

        <div style={{ marginTop: 20 }}>
          <button onClick={addToCart} className="primary">Add to cart</button>
          <button onClick={()=>router.push('/cart')} className="outline">Go to cart</button>
        </div>
      </div>
    </div>
  );
}
