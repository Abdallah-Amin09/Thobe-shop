import { useRef, useState } from 'react';

export default function ImageZoom({ src }: { src: string }) {
  const ref = useRef<HTMLDivElement|null>(null);
  const [zoom, setZoom] = useState(false);
  return (
    <div style={{ marginTop: 12 }}>
      <div style={{ width: 400, height: 400, overflow: 'hidden', borderRadius: 8, border: '1px solid #eee' }}>
        <img src={src} style={{ width: '100%', height: '100%', objectFit: 'cover', transform: zoom ? 'scale(1.8)' : 'scale(1)', transition: 'transform .3s' }} onMouseEnter={()=>setZoom(true)} onMouseLeave={()=>setZoom(false)} />
      </div>
    </div>
  );
}
