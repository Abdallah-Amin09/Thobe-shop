import Link from 'next/link';

export default function Layout({ children }: any) {
  return (
    <div>
      <nav className="nav">
        <div className="brand"><Link href="/">Thobe Designer</Link></div>
        <div className="links">
          <Link href="/cart">Cart</Link>
          <Link href="/admin">Admin</Link>
        </div>
      </nav>
      <main>{children}</main>
      <footer className="footer">© Thobe Designer</footer>
    </div>
  );
}
