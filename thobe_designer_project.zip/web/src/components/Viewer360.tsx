import { useState } from 'react';

export default function Viewer360({ images }: { images: string[] }) {
  const [index, setIndex] = useState(0);

  function prev(){ setIndex(i=> (i-1+images.length)%images.length); }
  function next(){ setIndex(i=> (i+1)%images.length); }

  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{ width: 400, height: 400, margin: '0 auto' }}>
        <img src={images[index]} style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 8 }} />
      </div>
      <div style={{ marginTop: 8 }}>
        <button onClick={prev} className="outline">◀</button>
        <button onClick={next} className="outline">▶</button>
      </div>
    </div>
  );
}
